import { getContactInfo } from '@bundle:com.example.wechatproject/entry/ets/model/WeChatData';
import { WeChatColor } from '@bundle:com.example.wechatproject/entry/ets/model/WeChatData';
import { CommonTitleBar } from '@bundle:com.example.wechatproject/entry/ets/components/CommonTitleBar';
import router from '@ohos:router';
export class ChatPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.contactsInfo = getContactInfo();
        this.nickname = router.getParams()['nickname'];
        this.text = this.contactsInfo.find(contact => contact.nickName === this.nickname).chatInfo;
        this.portrait = this.contactsInfo.find(contact => contact.nickName === this.nickname).portrait;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.contactsInfo !== undefined) {
            this.contactsInfo = params.contactsInfo;
        }
        if (params.nickname !== undefined) {
            this.nickname = params.nickname;
        }
        if (params.text !== undefined) {
            this.text = params.text;
        }
        if (params.portrait !== undefined) {
            this.portrait = params.portrait;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/ChatPage.ets(16:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 最上方的标题栏
                    CommonTitleBar(this, { attribute: { bg_color: WeChatColor, title_text: this.nickname } }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create();
            Flex.debugLine("pages/ChatPage.ets(20:7)");
            Flex.width('100%');
            Flex.height(48);
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Start });
            Stack.debugLine("pages/ChatPage.ets(21:9)");
            Stack.width('150px');
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 对方的头像 左上角
            Image.create($rawfile(this.portrait));
            Image.debugLine("pages/ChatPage.ets(23:11)");
            // 对方的头像 左上角
            Image.width('120px');
            // 对方的头像 左上角
            Image.height('120px');
            // 对方的头像 左上角
            Image.margin({ left: '20px', top: '30px', right: '0px' });
            // 对方的头像 左上角
            Image.border({
                radius: 4
            });
            if (!isInitialRender) {
                // 对方的头像 左上角
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Start });
            Stack.debugLine("pages/ChatPage.ets(33:9)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 对方说的一句话
            Text.create(this.text);
            Text.debugLine("pages/ChatPage.ets(35:11)");
            // 对方说的一句话
            Text.fontSize('16fp');
            // 对方说的一句话
            Text.fontColor('black');
            // 对方说的一句话
            Text.textAlign(TextAlign.Start);
            // 对方说的一句话
            Text.height('100%');
            // 对方说的一句话
            Text.margin({ left: '20px', top: '30px', right: '0px' });
            if (!isInitialRender) {
                // 对方说的一句话
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 对方说的一句话
        Text.pop();
        Stack.pop();
        Flex.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 打字框 最下方
            Image.create({ "id": 0, "type": 30000, params: ['input.jpg'], "bundleName": "com.example.wechatproject", "moduleName": "entry" });
            Image.debugLine("pages/ChatPage.ets(47:7)");
            // 打字框 最下方
            Image.width('1195px');
            // 打字框 最下方
            Image.height('165px');
            // 打字框 最下方
            Image.border({
                radius: 4
            });
            // 打字框 最下方
            Image.offset({ x: "0vp", y: "670vp" });
            if (!isInitialRender) {
                // 打字框 最下方
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ChatPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ChatPage.js.map