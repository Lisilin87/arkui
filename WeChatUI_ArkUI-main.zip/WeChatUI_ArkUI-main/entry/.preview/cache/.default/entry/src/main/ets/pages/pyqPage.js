import { getContactInfo } from '@bundle:com.example.wechatproject/entry/ets/model/WeChatData';
import { WeChatColor } from '@bundle:com.example.wechatproject/entry/ets/model/WeChatData';
import { CommonTitleBar } from '@bundle:com.example.wechatproject/entry/ets/components/CommonTitleBar';
import router from '@ohos:router';
export class pyqPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.contactsInfo = getContactInfo();
        this.nickname = router.getParams()['nickname'];
        this.text = this.contactsInfo.find(contact => contact.nickName === this.nickname).chatInfo;
        this.portrait = this.contactsInfo.find(contact => contact.nickName === this.nickname).portrait;
        this.vxnumber = this.contactsInfo.find(contact => contact.nickName === this.nickname).vxnumber;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.contactsInfo !== undefined) {
            this.contactsInfo = params.contactsInfo;
        }
        if (params.nickname !== undefined) {
            this.nickname = params.nickname;
        }
        if (params.text !== undefined) {
            this.text = params.text;
        }
        if (params.portrait !== undefined) {
            this.portrait = params.portrait;
        }
        if (params.vxnumber !== undefined) {
            this.vxnumber = params.vxnumber;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/pyqPage.ets(16:5)");
            Column.width("100%");
            Column.height("100%");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new CommonTitleBar(this, { attribute: { bg_color: WeChatColor, title_text: " " } }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/pyqPage.ets(18:7)");
            Column.width("100%");
            Column.height("100%");
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create($rawfile(this.portrait));
            Image.debugLine("pages/pyqPage.ets(19:9)");
            Image.width("145.22vp");
            Image.height("128vp");
            Image.offset({ x: "-102.37vp", y: "-167.5vp" });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.nickname);
            Text.debugLine("pages/pyqPage.ets(23:9)");
            Text.width("135.83vp");
            Text.height("34.96vp");
            Text.offset({ x: "54.36vp", y: "-305.52vp" });
            Text.fontSize("24fp");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("微信号：" + this.vxnumber);
            Text.debugLine("pages/pyqPage.ets(28:9)");
            Text.width("200vp");
            Text.height("60vp");
            Text.offset({ x: "86.09vp", y: "-314.88vp" });
            Text.fontSize("14fp");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("地区：北京理工大学");
            Text.debugLine("pages/pyqPage.ets(33:9)");
            Text.width("200vp");
            Text.height("60vp");
            Text.offset({ x: "84.42vp", y: "-346.18vp" });
            Text.fontSize("14fp");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/pyqPage.ets(38:9)");
            Row.width("360vp");
            Row.height("53.68vp");
            Row.offset({ x: "0vp", y: "-220.76vp" });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("备注和标签");
            Text.debugLine("pages/pyqPage.ets(39:11)");
            Text.width("200vp");
            Text.height("60vp");
            Text.fontSize("22fp");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['arrow.png'], "bundleName": "com.example.wechatproject", "moduleName": "entry" });
            Image.debugLine("pages/pyqPage.ets(43:11)");
            Image.width("60vp");
            Image.height("57.57vp");
            Image.offset({ x: "94.33vp", y: "1.95vp" });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/pyqPage.ets(52:9)");
            Row.width("360vp");
            Row.height("66.67vp");
            Row.offset({ x: "0vp", y: "50.5vp" });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['shipin.jpg'], "bundleName": "com.example.wechatproject", "moduleName": "entry" });
            Image.debugLine("pages/pyqPage.ets(53:11)");
            Image.width("168.25vp");
            Image.height("63.47vp");
            Image.offset({ x: "90.85vp", y: "4.96vp" });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/pyqPage.ets(66:7)");
            Row.width("360vp");
            Row.height("68.15vp");
            Row.offset({ x: "-40vp", y: "-278.01vp" });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['faxiaoxi.jpg'], "bundleName": "com.example.wechatproject", "moduleName": "entry" });
            Image.debugLine("pages/pyqPage.ets(67:9)");
            Image.width("168.24vp");
            Image.height("65.07vp");
            Image.offset({ x: "145.67vp", y: "1.46vp" });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/pyqPage.ets(75:7)");
            Row.width("360vp");
            Row.height("53.68vp");
            Row.offset({ x: "0vp", y: "-552.92vp" });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("朋友权限");
            Text.debugLine("pages/pyqPage.ets(76:9)");
            Text.width("200vp");
            Text.height("60vp");
            Text.fontSize("22fp");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['arrow.png'], "bundleName": "com.example.wechatproject", "moduleName": "entry" });
            Image.debugLine("pages/pyqPage.ets(80:9)");
            Image.width("60vp");
            Image.height("50vp");
            Image.offset({ x: "94.33vp", y: "1.95vp" });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/pyqPage.ets(88:7)");
            Row.width("360vp");
            Row.height("41.16vp");
            Row.offset({ x: "0vp", y: "-460.88vp" });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("更多信息");
            Text.debugLine("pages/pyqPage.ets(89:9)");
            Text.width("200vp");
            Text.height("60vp");
            Text.fontSize("22fp");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['arrow.png'], "bundleName": "com.example.wechatproject", "moduleName": "entry" });
            Image.debugLine("pages/pyqPage.ets(93:9)");
            Image.width("60vp");
            Image.height("50vp");
            Image.offset({ x: "94.33vp", y: "1.95vp" });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/pyqPage.ets(101:7)");
            Row.width("360vp");
            Row.height("53.68vp");
            Row.offset({ x: "0vp", y: "-559.41vp" });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("朋友圈");
            Text.debugLine("pages/pyqPage.ets(102:9)");
            Text.width("200vp");
            Text.height("60vp");
            Text.fontSize("22fp");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['arrow.png'], "bundleName": "com.example.wechatproject", "moduleName": "entry" });
            Image.debugLine("pages/pyqPage.ets(106:9)");
            Image.width("60vp");
            Image.height("50vp");
            Image.offset({ x: "94.33vp", y: "-5.95vp" });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new pyqPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=pyqPage.js.map