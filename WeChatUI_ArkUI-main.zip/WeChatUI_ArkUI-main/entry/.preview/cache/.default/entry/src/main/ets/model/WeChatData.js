import { UserInfo } from '@bundle:com.example.wechatproject/entry/ets/model/WCUserInfo';
const ContactInfo = [
    {
        "portrait": "yinzhi.png",
        "nickName": "银枝",
        "chatInfo": "我谨在此，以一朵玫瑰的沉重份量，向你致意。",
        "time": "18:30",
        "vxnumber": "yz12345"
    },
    {
        "portrait": "huohuo.png",
        "nickName": "藿藿",
        "chatInfo": "用这令旗，不仅调兵遣将能胜人一筹，投降也能先人一步……",
        "time": "18:30",
        "vxnumber": "hh12345"
    },
    {
        "portrait": "tuopa.png",
        "nickName": "托帕",
        "chatInfo": "钱是手段，不是目的，工作才使人快乐…这可是最基本的道理。",
        "time": "17:29",
        "vxnumber": "tp12345"
    },
    {
        "portrait": "jl.png",
        "nickName": "镜流",
        "chatInfo": "我的剑，谁要学，我便教。",
        "time": "17:29",
        "vxnumber": "jl12345"
    },
    {
        "portrait": "fuxuan.png",
        "nickName": "符玄",
        "chatInfo": "知识要用苦痛来换取。",
        "time": "17:29",
        "vxnumber": "fx12345"
    },
    {
        "portrait": "danheng.png",
        "nickName": "丹恒•饮月",
        "chatInfo": "我不是任何人的影子。",
        "time": "17:29",
        "vxnumber": "dhyy12345"
    },
    {
        "portrait": "kafuka.png",
        "nickName": "卡芙卡",
        "chatInfo": "除我以外，你什么都不记得。",
        "time": "13:30",
        "vxnumber": "kfk12345"
    },
    {
        "portrait": "ren.png",
        "nickName": "刃",
        "chatInfo": "死亡何时而至？我等得有些心焦了。",
        "time": "13:30",
        "vxnumber": "r12345"
    },
    {
        "portrait": "luocha.png",
        "nickName": "罗刹",
        "chatInfo": "这具棺柩非我之物。在下只是受人所托，将其遗体送回罗浮安置而已。",
        "time": "14:30",
        "vxnumber": "lc12345"
    },
    {
        "portrait": "yinlang.png",
        "nickName": "银狼",
        "chatInfo": "这次能让我玩得开心点吗？",
        "time": "14:30",
        "vxnumber": "yl12345"
    },
    {
        "portrait": "jingyuan.png",
        "nickName": "景元",
        "chatInfo": "善弈者无通盘妙手。人们会为一子妙手力挽狂澜而喜，却不为大局危倾而忧。",
        "time": "15:30",
        "vxnumber": "jy12345"
    },
    {
        "portrait": "yanqing.png",
        "nickName": "彦卿",
        "chatInfo": "叫声老师，是敬你有一技之长。接下来，我可不会手下留情了。",
        "time": "15:30",
        "vxnumber": "ryq2345"
    },
    {
        "portrait": "bailu.png",
        "nickName": "白露",
        "chatInfo": "午餐需讲究君臣相佐。烟熏肉堡两个，奶茶一杯，实是治疗心病、保持心情愉快的不二之选！",
        "time": "16:30",
        "vxnumber": "blq2345"
    },
    {
        "portrait": "blny.png",
        "nickName": "布洛妮娅",
        "chatInfo": "就算遭到了裂界的侵蚀，这里始终是我们的家园，银鬃铁卫绝不会就此放弃。",
        "time": "17:30",
        "vxnumber": "blnyq2345"
    }
];
export function getContactInfo() {
    let contactList = [];
    ContactInfo.forEach(item => {
        contactList.push(new UserInfo(item.nickName, item.portrait, item.chatInfo, item.time, item.vxnumber));
    });
    return contactList;
}
export const WeChatColor = "#ededed";
//# sourceMappingURL=WeChatData.js.map