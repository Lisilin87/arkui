import { WeChatColor } from '@bundle:com.example.wechatproject/entry/ets/model/WeChatData';
import router from '@ohos:router';
export class CommonTitleBar extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.attribute = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.attribute !== undefined) {
            this.attribute = params.attribute;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create();
            Flex.debugLine("components/CommonTitleBar.ets(12:5)");
            Flex.width('100%');
            Flex.height(48);
            Flex.backgroundColor(this.attribute.bg_color);
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Start });
            Stack.debugLine("components/CommonTitleBar.ets(13:7)");
            Stack.layoutWeight(1);
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("<", { type: ButtonType.Normal });
            Button.debugLine("components/CommonTitleBar.ets(14:9)");
            Button.onClick(() => {
                router.back();
            });
            Button.width('120px');
            Button.height('120px');
            Button.backgroundColor(WeChatColor);
            Button.fontColor("black");
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Center });
            Stack.debugLine("components/CommonTitleBar.ets(25:7)");
            Stack.layoutWeight(2);
            Stack.padding({ right: 150 });
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.attribute.title_text);
            Text.debugLine("components/CommonTitleBar.ets(26:9)");
            Text.fontSize('18fp');
            Text.fontColor('black');
            Text.textAlign(TextAlign.Center);
            Text.height('100%');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Stack.pop();
        Flex.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
// 定义标题栏属性
class CommonTitleBarAttribute {
    constructor() {
        this.bg_color = WeChatColor; // 标题栏背景色
        this.title_text = ""; // 标题文字
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "CommonTitleBar", new CommonTitleBar(undefined, {}));
}
//# sourceMappingURL=CommonTitleBar.js.map