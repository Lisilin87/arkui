let userId = 1;
export class UserInfo {
    constructor(nickName, portrait, chatInfo, time, vxnumber) {
        this.userId = `${userId++}`;
        this.nickName = nickName;
        this.portrait = portrait;
        this.chatInfo = chatInfo;
        this.time = time;
        this.vxnumber = vxnumber;
    }
}
//# sourceMappingURL=WCUserInfo.js.map