# WeChatUI_Arkts
鸿蒙原生Arkts搭建的微信UI


程序截图
![](screenshots/chat.png)
![](screenshots/contacts.png)
![](screenshots/discovery.png)
![](screenshots/mine.png)